<?php echo e($slot); ?>

<?php /**PATH C:\xampp\OneDocProject\htdocs\OneDocProjectLive\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>