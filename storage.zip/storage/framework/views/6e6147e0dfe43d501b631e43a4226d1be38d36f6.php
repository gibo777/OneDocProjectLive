<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <!-- <h2 class="font-semibold text-xl text-gray-800 leading-tight"> -->
        <h2 class="font-semibold text-xl leading-tight text-center">
            <?php echo e(__('MEMO')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <?php //phpinfo(); ?>
<!-- <a href="<?php echo e(route('document.wordtopdf')); ?>">Convert Word To PDF</a> -->

<!-- <input id="memo_counter" type="text" name="memo_counter"> -->
<!-- <div id="myProgress" class="col-span-5">
    <div id="processing_bar" class="myBar"></div>
</div> -->

    <div class="" style="height: 550px;">
        <div class="max-w-7xl mx-auto py-2 sm:px-6 lg:px-8 h-100" style="height: 550px;">

        <div class="col-span-8 sm:col-span-8" >
            <form id="memo-form" action="<?php echo e(route('tmp.file.preview')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">

                <!-- MEMO MOBILE VIEW -->
                <div class="col-md-4 py-2 hidden" id="mobile-view">
                  <ul class="nav nav-tabs">
                    <li class="nav-link active"><a data-toggle="tab" href="#general-memo-mobile">General Memo</a></li>
                    <li class="nav-link"><a data-toggle="tab" href="#specific-memo-mobile">Specific Memo</a></li>
                    <li class="">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['name' => 'add_memo','class' => 'btn btn-primary btn-sm','ariaPressed' => 'true']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'add_memo','class' => 'btn btn-primary btn-sm','aria-pressed' => 'true']); ?>Add Memo <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </li>
                  </ul>
                  <div class="tab-content embed-responsive-item">
                    <!-- <div id="profile_info" class="tab-pane fade-in active" style="height: 550px;"> -->
                    <div id="general-memo-mobile" class="tab-pane fade-in active">
                        <div class="p-3">
                            GENERAL
                        </div>
                    </div>
                    <div id="specific-memo-mobile" class="tab-pane fade">
                        <div class="p-3">
                            SPECIFIC
                        </div>
                    </div>
                  </div>
                </div>
                <!-- MEMO PREVIEW -->
                <div class="row justify-content-center col-md-8 bg-gray-200 border items-center justify-center border border-secondary rounded-left">
                    <!-- <iframe id="preview-memo" src="http://localhost:8000/view-pdf" class="col-md-12" width="100%" height="550"> -->
                    <iframe id="preview-memo" src="" class="h-100 w-full" width="100%">

                    <!-- <iframe src="https://view.officeapps.live.com/op/view.aspx?src=<?php echo e(asset('storage/memo-archives/helloWorld.docx')); ?>" width="100%" height="550"> -->
                    <!-- <iframe src="" width="100%" height="550"> -->
                            <!-- This browser does not support PDFs. Please download the PDF to view it: <a href="<?php echo e(asset('storage/memo-archives/helloWorld.pdf')); ?>">Download PDF</a> -->


                    </iframe>
                    <?php 

                        /*@if(upload is image)
                            <img src="{{image url}}"/>
                        @elseif(upload is pdf)
                            <iframe src="{{pdf url}}" frameborder="0" style="width:100%;min-height:640px;"></iframe>
                        @elseif(upload is document)
                            <iframe src="https://view.officeapps.live.com/op/view.aspx?src={{urlendoe(doc url)}}" frameborder="0" style="width:100%;min-height:640px;"></iframe>
                        @else
                        //manage things here
                        @endif*/
                    ?>
                </div>

                <!-- MEMO DESKTOP VIEW -->
                <div class="col-md-4 py-0 bg-light border border-secondary h-100" id="desktop-view">
                  <ul class="nav nav-tabs">
                      <li class="nav-link active">
                          <a id="general-tab" data-toggle="tab" href="#general-memo-desktop">General&nbsp;&nbsp;
                          <?php $__currentLoopData = $memo_counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$memo_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($memo_count->memo_send_option=='g'): ?>
                            <span id="g_count" class="badge badge-primary badge-pill"><?php echo e($memo_count->memo_count); ?></span>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </a>
                      </li>
                      <li class="nav-link">
                          <a id="specific-tab" data-toggle="tab" href="#specific-memo-desktop">Personal&nbsp;&nbsp;
                          <?php $__currentLoopData = $memo_counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$memo_count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($memo_count->memo_send_option=='p'): ?>
                            <span id="s_count" class="badge badge-primary badge-pill"><?php echo e($memo_count->memo_count); ?></span>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </a>
                      </li>

                    <?php if(Auth::user()->department == 'HR'): ?>
                    <li class="nav-link">
                        <a data-toggle="tab" href="#add-memo-desktop" class="btn btn-primary">Add</a>
                    </li>
                    <?php endif; ?>
                  </ul>
                  <div class="tab-content embed-responsive-item scrollable" style="height: 500px;">
                    <!-- <div id="profile_info" class="tab-pane fade-in active" style="height: 550px;"> -->
                    <div id="general-memo-desktop" class="tab-pane fade-in active">
                        <div class="w-full pr-3">
                            <div class="row">
                              <div class="col-12">
                                <div class="list-group" id="general-list-tab" role="tablist">
                                  <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$memo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($memo->memo_send_option=='g'): ?>
                                    <a class="list-group-item list-group-item-action cut-text <?php echo e(($memo->is_viewed==1) ? 'bg-viewed' : ''); ?>" data-value="<?php echo e($memo->file_name); ?>" name="g-memo-list[]" id="<?php echo e($memo->id); ?>" data-toggle="list" href="#list-home" role="tab" aria-controls="home">
                                      <?php echo e(date('m/d/y',strtotime($memo->uploaded_at)).' - '.$memo->memo_subject); ?>

                                    </a>
                                    <input type="hidden" name="<?php echo e($memo->id); ?>" value="<?php echo e($memo->is_viewed); ?>">
                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="specific-memo-desktop" class="tab-pane fade">
                        <div class="w-full pr-3 ">
                            <div class="row">
                              <div class="col-12">
                                <div class="list-group" id="personal-list-tab" role="tablist">
                                  <?php 
                                  /*@foreach($memos as $key=>$memo)
                                  @if ($memo->memo_send_option=='p')
                                    <a class="list-group-item list-group-item-action cut-text" data-value="{{ $memo->file_name }}" name="p-memo-list[]" data-toggle="list" href="#list-home" role="tab" aria-controls="home">
                                      {{ date('m/d/y',strtotime($memo->uploaded_at)).' - '.$memo->memo_subject }}
                                    </a>
                                  @endif
                                  @endforeach*/
                                  ?>
                                </div>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div id="add-memo-desktop" class="tab-pane fade">
                        <div class="col-span-6 px-2 py-1 sm:col-span-6 w-full">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['value' => ''.e(__('Subject:')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(__('Subject:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'memo_subject','name' => 'memo_subject','type' => 'text','class' => 'mt-1 block w-full empty','autocomplete' => 'off']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'memo_subject','name' => 'memo_subject','type' => 'text','class' => 'mt-1 block w-full empty','autocomplete' => 'off']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'memo_subject','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_subject','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                        <div class="p-3">
                          <div class="row p-2">
                            <div class="col-span-12 sm:col-span-6 px-1">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => '','value' => ''.e(__('Sending Option:')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => '','value' => ''.e(__('Sending Option:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <select id="memo_send_option" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block empty" placeholder="Search" >
                                    <option value="">-Sending Option-</option>
                                    <option value="g">General</option>
                                    <option value="s">Personal</option>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'memo_send_option','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_send_option','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'file_created','hidden' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'file_created','hidden' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                            <div class="col-span-12 sm:col-span-4 px-3">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => '','value' => ''.e(__('Upload/Create:')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => '','value' => ''.e(__('Upload/Create:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <select id="memo_upload_create" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block" placeholder="Search" >
                                    <option value="u">Upload</option>
                                    <option value="c">Create</option>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'memo_send_option','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_send_option','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'text','id' => 'file_created','hidden' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','id' => 'file_created','hidden' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                          </div>
                        </div>
                        <div id="div_memo_recepients" class="col-span-6 sm:col-span-2 px-2 w-full hidden">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'memo_department','value' => ''.e(__('Department:')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_department','value' => ''.e(__('Department:')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <select id="memo_department" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block w-full" placeholder="Search" style="width: 100%;">
                                <option value="">All Departments</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->department_code); ?>"><?php echo e($department->department); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'memo_department','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_department','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'memo_recipient','value' => ''.e(__('Memo Recipient:')).'','class' => 'pt-3']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_recipient','value' => ''.e(__('Memo Recipient:')).'','class' => 'pt-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <select id="memo_recipient" name="memo_recipient[]" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block w-full empty" placeholder="Search" style="width: 100%;" multiple="multiple">
                                <!-- <option value="">-Select Recipient</option> -->
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->employee_id); ?>"><?php echo e($employee->last_name.', '.$employee->first_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'memo_recipient','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'memo_recipient','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>

                        <div class="px-2 pt-3">
                            <div class="input-group mb-3">

                              <div class="custom-file">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'file','class' => 'custom-file-input','id' => 'inputGroupFile02','name' => 'inputGroupFile02[]','disabled' => true,'multiple' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','class' => 'custom-file-input','id' => 'inputGroupFile02','name' => 'inputGroupFile02[]','disabled' => true,'multiple' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'custom-file-label','for' => 'inputGroupFile02','value' => ''.e(__('Choose File')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'custom-file-label','for' => 'inputGroupFile02','value' => ''.e(__('Choose File')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                              </div>
                            </div>
                        </div>

                        <div class="p-1">
                            <div class="input-group mb-3 items-center justify-center">
                              <div class="input-group-append">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'btn btn-secondary btn-sm','id' => 'preview_memo','value' => ''.e(__('Preview')).'','disabled' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-secondary btn-sm','id' => 'preview_memo','value' => ''.e(__('Preview')).'','disabled' => true]); ?><?php echo e(__('Preview')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                              </div>
                              <div class="input-group-append">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'btn btn-primary btn-sm','id' => 'send_memo','value' => ''.e(__('Preview')).'','disabled' => true]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-primary btn-sm','id' => 'send_memo','value' => ''.e(__('Preview')).'','disabled' => true]); ?><?php echo e(__('Send Memo')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
        </form>
        </div>

        </div>
    </div>

<!-- =========================================== -->
<!-- Modal for History -->
<div class="modal fade" id="modalMemoCreation" tabindex="-1" role="dialog" aria-labelledby="memoCreationLabel" data-backdrop="static">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title text-lg" id="leaveHistoryLabel">
            Memo Creation
        </h4>
        <button id="closeModal" type="button" class="close btn btn-primary fa fa-close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"></span></button>
      </div>
      <div class="modal-body bg-gray-50">
            <div class="grid grid-cols-6 gap-6 pb-3">
                <div class="col-span-6 sm:col-span-6 sm:justify-center font-medium scrollable">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 mt-4">
                                <div class="card-body">
                                    <form method="post" action="" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <textarea class="ckeditor form-control" name="wysiwyg-editor"></textarea>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
    </div>
  </div>
</div>
<!-- =========================================== -->


<?php 

// $homepage = file_get_contents('http://www.example.com/');
// echo $homepage;
?>

<script>
$(document).ready(function(){

    Pusher.logToConsole = true;

    var pusher = new Pusher('264cb3116052cba73db3', {
      cluster: 'us2',
      forceTLS: true
    });

    var channel = pusher.subscribe('my-channel');
    channel.bind("my-event", function(data) {
      // alert(data);
      // alert(JSON.stringify(data));
      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $.ajax({
          // url: window.location.origin+'/file-preview-memo',
          url: "<?php echo e(route('counts_pusher')); ?>",
          method: 'get',
          data: JSON.stringify(data), // prefer use serialize method
          success:function(data){
            // $("#nav-memo-counter").text(data.memo_counts);

            $("#g_count").text(data.memo_g_counts);
            $("#s_count").text(data.memo_s_counts);
            // alert('Hey Gibs');
          }
      });
    }); 


  $("#general-tab").on('click', function() {
    $("[name='g-memo-list[]']").each(function() {
      $(this).removeClass('active');
      $("#preview-memo").attr('src','');
    });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: "<?php echo e(route('memo.data')); ?>",
            method: 'get',
            // data: { 'file_path':  }, // prefer use serialize method
            success:function(data){
              // prompt('',data);
              $("#general-list-tab").empty();
              append_memo(data,"g");
            }
        });
  });

  $("#specific-tab").on('click', function() {
    $("[name='p-memo-list[]']").each(function(){
      $(this).removeClass('active');
      $("#preview-memo").attr('src','');
    });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: "<?php echo e(route('memo.data')); ?>",
            method: 'get',
            // data: { 'file_path':  }, // prefer use serialize method
            success:function(data){
              // prompt('',data);
              $("#personal-list-tab").empty();
              //
              append_memo(data,"p");
              // view_memo("[name='p-memo-list[]']");
            }
        });
  });


  $("[name='g-memo-list[]']").each(function() {
    $(this).on('click', function() {
    var memo_id_ee = $(this).attr('id');
      // alert('Gibs');
      // prompt('',"<?php echo e(str_replace('\\', '/', public_path('storage/memo-files/'))); ?>"+$(this).data('value'));
      // $("#preview-memo").attr('src', "<?php echo e(asset('storage/memo-files')); ?>/"+$(this).data('value'));
    $("[name='g-memo-list[]']").removeClass('active');
      $(this).removeClass('bg-viewed');
      $(this).addClass('active');

      bg_memo_viewed ("g",$(this).attr('id'));

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            // url: window.location.origin+'/file-preview-memo',
            url: "<?php echo e(route('view.memo')); ?>",
            method: 'get',
            data: { 'file_path': "<?php echo e(str_replace('\\', '/', public_path('storage/memo-files/'))); ?>"+$(this).data('value') }, // prefer use serialize method
            success:function(data){
              // prompt('',data);
                $("#preview-memo").removeAttr('src');
                $("#preview-memo").attr('src',data);
                $("[name='"+memo_id_ee+"']").val(1);
                memo_viewed(memo_id_ee)
                move(20);
            }
        });
    return false;
    });

  });

  function bg_memo_viewed (option,selected) {
    // alert(option+'\n'+selected);
    $("[name='"+option+"-memo-list[]']").each(function() {
      if ($(this).attr('id')!=selected) {
        if ($("[name='"+$(this).attr('id')+"']").val()==1) {
          $(this).addClass('bg-viewed');
        }
      }``
    });
    return false;
  }


  function append_memo(data, option) {
    var list_tab='';
    var bg_viewed='';
    if (option=='g') {
      list_tab = "#general-list-tab";
    } else {
      list_tab = "#personal-list-tab";
    }

      for (var n=0; n<data.length; n++) {
        // prompt('',data[n]['memo_send_option'] + '\n' +option);
        if (data[n]['memo_send_option']==option) {
          // prompt('', data[n]['memo_subject']);
          if (data[n]['is_viewed']==1) { bg_viewed = 'bg-viewed'; } else { bg_viewed = ''; }
          $(list_tab).append('<a class="list-group-item list-group-item-action cut-text '+bg_viewed+'" data-value="'+data[n]['file_name']+'" name="'+option+'-memo-list[]" id="'+data[n]['id']+'" data-toggle="list" href="#list-home" role="tab" aria-controls="home">'+data[n]['uploaded_at']+' - '+data[n]['memo_subject']+'</a>');
          $(list_tab).append('<input type="hidden" name="'+data[n]['id']+'" value="'+data[n]['is_viewed']+'">');
        }
      }
      view_memo("[name='"+option+"-memo-list[]']", option);
  }

  function view_memo(input_name, option='') {
    // alert(input_name);
        $(input_name).each(function() {
          $(this).on('click', function() {
            var memo_id_ee = $(this).attr('id');
            $(input_name).removeClass('active');
            $(input_name).removeClass('bg-viewed');
            bg_memo_viewed (option,$(this).attr('id'));
            $(this).addClass('active');
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
              $.ajax({
                  // url: window.location.origin+'/file-preview-memo',
                  url: "<?php echo e(route('view.memo')); ?>",
                  method: 'get',
                  data: { 'file_path': "<?php echo e(str_replace('\\', '/', public_path('storage/memo-files/'))); ?>"+$(this).data('value') }, // prefer use serialize method
                  success:function(data){
                    // prompt('',data);
                      $("#preview-memo").removeAttr('src');
                      $("#preview-memo").attr('src',data);
                      $("[name='"+memo_id_ee+"']").val(1);
                      memo_viewed(memo_id_ee);
                      move(20);
                  }
              });
          return false;
          });
        });
  } // End view_memo method

  function memo_viewed(id) {
    // alert ('Help me Lord');
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $.ajax({
        // url: window.location.origin+'/file-preview-memo',
        url: "<?php echo e(route('memo.viewed')); ?>",
        method: 'post',
        data: { 'id': id }, // prefer use serialize method
        success:function(data){
          // alert(data);
        }
    });
  }



    var CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
    var memo_ctr = 0;

    if(window.matchMedia("(max-width: 767px)").matches){
        // The viewport is less than 768 pixels wide
        $("#desktop-view").hide();
        $("#mobile-view").show();
    } else{
        // The viewport is at least 768 pixels wide
        $("#desktop-view").show();
        $("#mobile-view").hide();
    }

    function send_memo_validation() {
      var memo_subject      = $("#memo_subject").val(),
          memo_send_option  = $("#memo_send_option").val(),
          memo_file         = $("#inputGroupFile02").val(),
          memo_department   = $("#memo_department").val(),
          memo_recipient    = $("#memo_recipient").select2('val');
          memo_ctr=0;

      if ($.trim(memo_subject)=='') {
        memo_ctr++
      }
      if ($.trim(memo_send_option)=='') {
        memo_ctr++
      }
      if ($.trim(memo_file)=='') {
        memo_ctr++
      }
      if (memo_send_option=='p') {
        if ($.trim(memo_department)=='') {
          if (memo_recipient.length==0) {
            memo_ctr++
          }
        }
      }
      if ($.trim($("#preview-memo").attr('src'))=='') {
        memo_ctr++;
      }

      if (memo_ctr>0) {
        $("#send_memo").prop('disabled',true);
      } else {
        $("#send_memo").prop('disabled',false);
      }

    }

    $('.custom-file-input').on('change', function() {
        // alert($(this).val());return false;
              // Get the selected file
              var files = $('#inputGroupFile02')[0].files;
              var file_extension = $('#inputGroupFile02').val().split('.').pop();

              if(files.length > 0){
                switch (file_extension) {
                    case 'docx': case 'pdf': case 'png': case 'jpg': case 'jpeg': case 'gif':
                         var fd = new FormData();

                         // Append data 
                         fd.append('file',files[0]);
                         fd.append('_token',CSRF_TOKEN);

                         // Hide alert 
                         // $('#responseMsg').hide();

                         // AJAX request 
                         // $.ajax({
                         //   url: "<?php echo e(route('uploadFile')); ?>",
                         //   method: 'post',
                         //   data: fd,
                         //   contentType: false,
                         //   processData: false,
                         //   // dataType: 'json',
                         //   success: function(data){
                         //    // prompt('',data);
                         //     // $("#file_created").val(data);
                             $("#preview_memo").prop("disabled",false);
                         //   },
                         //   error: function(response){
                         //      console.log("error : " + JSON.stringify(response) );
                         //   }
                         // });
                         let fileName = $(this).val().split('\\').pop();
                         $(this).next('.custom-file-label').addClass("selected").html(fileName); 
                     break;
                     default:
                        $("#preview_memo").prop("disabled",true);
                        alert('Unsupported file!');
                     break;
                }
              }/*else{
                 $("#preview_memo").prop("disabled",true);
                 alert("Please select a file.");
              }*/


    });


    $("#memo_send_option").on('change', function() {
        if ($(this).val()=='') {
            $("#inputGroupFile02").prop('disabled',true);
        } else {
            $("#inputGroupFile02").prop('disabled',false);
            if($(this).val()=='p') {
                $("#div_memo_recepients").removeClass('hidden');
            } else {
                $("#div_memo_recepients").addClass('hidden');
            }   
        }
    });

    $("#memo_upload_create").on('change',function() {
      if ($(this).val()=='c') {
        $("#modalMemoCreation").modal('show');

      }
    });

    $('#closeModal').click(function () {
      $("#memo_upload_create").val('u');
    });

    $("#memo_subject").on('change paste keyup keydown', function() {
       send_memo_validation();
    });
    $("#memo_send_option").on('change', function() {
       send_memo_validation();
    });
    $("#inputGroupFile02").on('change paste keyup keydown', function() {
       send_memo_validation();
    });
    $("#memo_department").on('change paste keyup keydown', function() {
       send_memo_validation();
    });
    $("#memo_recipient").on('change paste keyup keydown', function() {
       send_memo_validation();
    });

    $("#memo_recipient").select2({
      placeholder: 'Select Recipient/s',
      width: 'resolve'
    });

    $('#preview_memo').on('click', function() {
              var files = $('#inputGroupFile02')[0].files;
              var file_extension = $('#inputGroupFile02').val().split('.').pop();

              if(files.length > 0){
                switch (file_extension) {
                    case 'docx': case 'pdf': case 'png': case 'jpg': case 'jpeg': case 'gif':
                         var fd = new FormData();

                         // Append data 
                         fd.append('file',files[0]);
                         fd.append('_token',CSRF_TOKEN);

                         // Hide alert 
                         // $('#responseMsg').hide();

                         // AJAX request 
                         $.ajax({
                           url: "<?php echo e(route('tmp.file.preview')); ?>",
                           method: 'post',
                           data: fd,
                           contentType: false,
                           processData: false,
                           // dataType: 'json',
                           success: function(data){
                            // alert("<?php echo e(route('file.preview')); ?>"); return false;
                              $.ajaxSetup({
                                  headers: {
                                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                  }
                              });
                              $.ajax({
                                  // url: window.location.origin+'/file-preview-memo',
                                  url: "<?php echo e(route('file.preview')); ?>",
                                  method: 'get',
                                  // data: $("#memo-form").serialize(), // prefer use serialize method
                                  data: { 'file': $("#inputGroupFile02").val() }, // prefer use serialize method
                                  success:function(data){
                                      $("#preview-memo").removeAttr('src');
                                      $("#preview-memo").attr('src',data);
                                      send_memo_validation();
                                      move(20);
                                  }
                              });
                           },
                           error: function(response){
                              console.log("error : " + JSON.stringify(response) );
                           }
                         });
                         let fileName = $(this).val().split('\\').pop();
                         $(this).next('.custom-file-label').addClass("selected").html(fileName); 
                     break;
                     default:
                        $("#preview_memo").prop("disabled",true);
                        alert('Unsupported file!');
                     break;
                }
              }
            return false;
    });

    $("#send_memo").on('click', function() {
      // prompt('',$("#memo-form").serialize()); return false;
        var files = $('#inputGroupFile02')[0].files;
        var file_extension = $('#inputGroupFile02').val().split('.').pop();

        if(files.length > 0){
          switch (file_extension) {
              case 'docx': case 'pdf': case 'png': case 'jpg': case 'jpeg': case 'gif':
                   var fd = new FormData();
                   // prompt('',fd.length); return false;

                   // Append data 
                   fd.append('file',files[0]);
                   fd.append('_token',CSRF_TOKEN);
                   fd.append('memo_subject',$("#memo_subject").val());
                   fd.append('send_option',$("#memo_send_option").val());
                   if ($("#memo_send_option").val()=='p') {
                    fd.append('department',$("#memo_department").val());
                    fd.append('recipient', $("#memo_recipient").val());
                   }

                   // Hide alert 
                   $('#responseMsg').hide();

                   // AJAX request 
                   $.ajax({
                     url: "<?php echo e(route('send.memo')); ?>",
                     method: 'post',
                     data: fd,
                     contentType: false,
                     processData: false,
                     // dataType: 'json',
                     beforeSend: function (xhr) {
                        $("#loadingModal").modal("show");
                     },
                     success: function(data){
                      // prompt('',data);
                      // alert('success?');
                        $("#loadingModal").modal("hide");
                        $("#loadingModal").removeClass("in");
                        // $("#loadingModal").addClass("hidden");
                     },
                     error: function(response){
                        console.log("error : " + JSON.stringify(response) );
                     }
                   });
                   /*let fileName = $(this).val().split('\\').pop();
                   $(this).next('.custom-file-label').addClass("selected").html(fileName); */
               break;
               default:
                  $("#preview_memo").prop("disabled",true);
                  alert('Unsupported file!');
               break;
          }
        }
        return false;
    });

    var i = 0;
    var ctr = 0;
    function move(counts) {
        if (i == 0) {
        i = 1;
        // var elem = $("#processing_bar");
        var width = 0;
        var id = setInterval(frame, (counts*2));
        var ctr_success=0;
            function frame() {
              if (width >= 100) {
                clearInterval(id);
                i = 0;
              } else {
                    // ctr_success = data;
                    ctr = ctr+(1/counts)*100;
                    width = ctr;
                    // $("#test_count").html(ctr_success+"|"+counts+"|"+ctr.toFixed(2)+"|"+leaveID[n]['id'])
                    // elem.width(width + "%");
                    if (Math.round(width)<100) {
                        // $("#processing_bar").html(width.toFixed(2) + "%");
                    } else {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            // url: window.location.origin+'/file-preview-memo',
                            url: "<?php echo e(route('remove.tmp.file')); ?>",
                            method: 'get',
                            data: $("#memo-form").serialize(), // prefer use serialize method
                            // data: { 'file': $("#inputGroupFile02").val() }, // prefer use serialize method
                            success:function(data){
                            }
                        });

                    }
              }
            }
        }
    }


    $('.ckeditor').ckeditor();
    CKEDITOR.replace('wysiwyg-editor', {
        filebrowserUploadUrl: "<?php echo e(route('ckeditor.image-upload', ['_token' => csrf_token() ])); ?>",
        filebrowserUploadMethod: 'form'
    });

});
</script>

<!-- loading-blue-circle -->
<div class="modal in bg-light opacity-75" id="loadingModal" tabindex="-1" role="dialog" data-backdrop="static">
    <div class="modal-dialog modal-xl" >
        <div class="modal-dialog-centered">  
            <img src="<?php echo e(asset('/img/misc/loading-blue-circle.gif')); ?>">
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\Users\Acer\Desktop\_Gibs\jet_onedoc_project\resources\views//hris/hr-management/hr-memos.blade.php ENDPATH**/ ?>