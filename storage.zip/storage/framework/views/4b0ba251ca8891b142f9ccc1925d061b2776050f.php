<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.gilbert','data' => ['submit' => 'updateProfileInformation']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-gilbert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['submit' => 'updateProfileInformation']); ?>

<link href="<?php echo e(asset('/selectsearch/select2/dist/css/select2.min.css')); ?>" rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="<?php echo e(asset('/css/dataTables.bootstrap4.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/font-awesome/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/jquery-ui-1.13.1.custom/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/jquery-ui-1.13.1.custom/jquery-ui.min.css')); ?>">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 
<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.6.0.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('/selectsearch/jquery-3.2.1.min.js')); ?>" type='text/javascript'></script>
<script type="text/javascript" src="<?php echo e(asset('/js/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('/selectsearch/select2/dist/js/select2.min.js')); ?>" type='text/javascript'></script>

<!-- TABLE WITH PAGINATION beging -->
<script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/jquery-ui-1.13.1.custom/jquery-ui.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/jquery-ui-1.13.1.custom/jquery-ui.min.js')); ?>"></script>

     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('e-Signature')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('description', null, []); ?> 
        <?php echo e(__('')); ?>

     <?php $__env->endSlot(); ?>

     <?php $__env->slot('form', null, []); ?> 

        <div class="col-span-8 sm:col-span-8"> 
        <div class="row">
            <div class="col-md-12">
                <div class="row pb-2">
                    <div class="col-md-4">
                        <div class="col-span-8 sm:col-span-4">
                            <iframe id="preview-memo" src="" class="col-md-12 bg-light" width="100%" height="150"></iframe>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="col-span-8 sm:col-span-4">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'last_name','value' => ''.e(__('e-Signature')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'last_name','value' => ''.e(__('e-Signature')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <textarea id="reason" name="reason" class="border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm mt-1 block w-full empty" wire:model.defer="state.reason" /> </textarea>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'last_name','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'last_name','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="col-span-8 sm:col-span-1 item-center">
                              <div class="custom-file">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['type' => 'file','class' => 'custom-file-input','id' => 'eSignature_file']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','class' => 'custom-file-input','id' => 'eSignature_file']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'custom-file-label','for' => 'eSignature_file','value' => ''.e(__('Choose e-Signature Image')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'custom-file-label','for' => 'eSignature_file','value' => ''.e(__('Choose e-Signature Image')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                              </div>
                              <div class="">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['class' => 'btn btn-secondary btn-sm','id' => 'preview_esignature','value' => ''.e(__('Preview')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn btn-secondary btn-sm','id' => 'preview_esignature','value' => ''.e(__('Preview')).'']); ?><?php echo e(__('Preview')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                              </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        </div>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('actions', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.action-message','data' => ['class' => 'mr-3','on' => 'saved']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mr-3','on' => 'saved']); ?>
            <?php echo e(__('Saved.')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['wire:loading.attr' => 'disabled','wire:target' => 'photo']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.attr' => 'disabled','wire:target' => 'photo']); ?>
            <?php echo e(__('Save')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
    <script>
$(document).ready(function(){
    var CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
    var memo_ctr = 0;

    /*if(window.matchMedia("(max-width: 767px)").matches){
        // The viewport is less than 768 pixels wide
        $("#desktop-view").hide();
        $("#mobile-view").show();
    } else{
        // The viewport is at least 768 pixels wide
        $("#desktop-view").show();
        $("#mobile-view").hide();
    }*/

    $('#eSignature_file').on('change', function() {
        alert('heyyy'); return false;
             /* // Get the selected file
              var files = $('#eSignature_file')[0].files;
              var file_extension = $('#eSignature_file').val().split('.').pop();

              if(files.length > 0){
                switch (file_extension) {
                    case 'png': case 'jpg': case 'jpeg':
                         var fd = new FormData();

                         // Append data 
                         fd.append('file',files[0]);
                         fd.append('_token',CSRF_TOKEN);

                         // Hide alert 
                         $('#responseMsg').hide();

                         // AJAX request 
                         $.ajax({
                           url: "<?php echo e(route('uploadFile')); ?>",
                           method: 'post',
                           data: fd,
                           contentType: false,
                           processData: false,
                           // dataType: 'json',
                           success: function(data){
                            // alert(data);
                           },
                           error: function(response){
                              console.log("error : " + JSON.stringify(response) );
                           }
                         });
                         let fileName = $(this).val().split('\\').pop();
                         $(this).next('.custom-file-label').addClass("selected").html(fileName); 
                     break;
                     default:
                        $("#preview_memo").prop("disabled",true);
                        alert('Unsupported file!');
                     break;
                }
            }*/
    });


    $('#preview_esignature').on('click', function() {
            /*$.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            // alert("<?php echo e(route('file.preview')); ?>");
            // alert($("#inputGroupFile02").val()); return false;
            // alert(window.location.origin+'/file-preview-memo'); return false;
            $.ajax({
                // url: window.location.origin+'/file-preview-memo',
                url: "<?php echo e(route('file.preview')); ?>",
                method: 'get',
                // data: $("#memo-form").serialize(), // prefer use serialize method
                data: { 'file': $("#inputGroupFile02").val() }, // prefer use serialize method
                success:function(data){
                }
            });*/

            return false;

        // let fileName = $(this).val().split('\\').pop(); 
        // $(this).next('.custom-file-label').addClass("selected").html(fileName); 
    });

});
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Acer\Desktop\_Gibs\jet_onedoc_project\resources\views/livewire/profile/e-signature.blade.php ENDPATH**/ ?>