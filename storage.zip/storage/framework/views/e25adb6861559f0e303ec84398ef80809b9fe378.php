<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" /> -->

     <?php $__env->slot('header', null, []); ?> 
        <!-- <h2 class="font-semibold text-xl text-gray-800 leading-tight"> -->
        <h2 class="font-semibold text-xl leading-tight text-center pt-1">
            <?php echo e(__('PERSONNEL DATA')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    
        <div class="max-w-6xl mx-auto mt-1">
            <div class="p-1">
              <ul class="nav nav-tabs">
                <li class="nav-link active"><a data-toggle="tab" href="#profile_info">Personal Data</a></li>
                <li class="nav-link"><a data-toggle="tab" href="#accounting_data">Accounting Data</a></li>
                <li class="nav-link"><a data-toggle="tab" href="#family_background">Family Background</a></li>
                <li class="nav-link"><a data-toggle="tab" href="#educational_background">Educational Background</a></li>
                <li class="nav-link"><a data-toggle="tab" href="#employment_history">Employment History</a></li>
                
                <li class="nav-link"><a data-toggle="tab" href="#account_security">Account Security</a></li>
              </ul>

              <div class="tab-content">
                <div id="profile_info" class="tab-pane fade-in active">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.update-profile-information-form')->html();
} elseif ($_instance->childHasBeenRendered('klssXXZ')) {
    $componentId = $_instance->getRenderedChildComponentId('klssXXZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('klssXXZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('klssXXZ');
} else {
    $response = \Livewire\Livewire::mount('profile.update-profile-information-form');
    $html = $response->html();
    $_instance->logRenderedChild('klssXXZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>
                <div id="accounting_data" class="tab-pane fade">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.accounting-data')->html();
} elseif ($_instance->childHasBeenRendered('GtlgCP4')) {
    $componentId = $_instance->getRenderedChildComponentId('GtlgCP4');
    $componentTag = $_instance->getRenderedChildComponentTagName('GtlgCP4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GtlgCP4');
} else {
    $response = \Livewire\Livewire::mount('profile.accounting-data');
    $html = $response->html();
    $_instance->logRenderedChild('GtlgCP4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>
                <div id="family_background" class="tab-pane fade">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.family-background')->html();
} elseif ($_instance->childHasBeenRendered('gkwgSEO')) {
    $componentId = $_instance->getRenderedChildComponentId('gkwgSEO');
    $componentTag = $_instance->getRenderedChildComponentTagName('gkwgSEO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gkwgSEO');
} else {
    $response = \Livewire\Livewire::mount('profile.family-background');
    $html = $response->html();
    $_instance->logRenderedChild('gkwgSEO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>
                <div id="educational_background" class="tab-pane fade">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.educational-background')->html();
} elseif ($_instance->childHasBeenRendered('QlKSyMc')) {
    $componentId = $_instance->getRenderedChildComponentId('QlKSyMc');
    $componentTag = $_instance->getRenderedChildComponentTagName('QlKSyMc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QlKSyMc');
} else {
    $response = \Livewire\Livewire::mount('profile.educational-background');
    $html = $response->html();
    $_instance->logRenderedChild('QlKSyMc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>
                <div id="employment_history" class="tab-pane fade">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.employment-history')->html();
} elseif ($_instance->childHasBeenRendered('2hUlghU')) {
    $componentId = $_instance->getRenderedChildComponentId('2hUlghU');
    $componentTag = $_instance->getRenderedChildComponentTagName('2hUlghU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2hUlghU');
} else {
    $response = \Livewire\Livewire::mount('profile.employment-history');
    $html = $response->html();
    $_instance->logRenderedChild('2hUlghU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>
                <div id="e-signature" class="tab-pane fade">
                        <?php if(Laravel\Fortify\Features::canUpdateProfileInformation()): ?>
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.e-signature')->html();
} elseif ($_instance->childHasBeenRendered('C8ue518')) {
    $componentId = $_instance->getRenderedChildComponentId('C8ue518');
    $componentTag = $_instance->getRenderedChildComponentTagName('C8ue518');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('C8ue518');
} else {
    $response = \Livewire\Livewire::mount('profile.e-signature');
    $html = $response->html();
    $_instance->logRenderedChild('C8ue518', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.section-border','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-section-border'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php endif; ?>
                </div>


                <?php
                 /*<div id="account_security" class="tab-pane fade max-w-75 ">

                        @if (Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updatePasswords()))
                            <div class="mt-10 sm:mt-0">
                                @livewire('profile.update-password-form')
                            </div>
                        @endif

                        @if (Laravel\Fortify\Features::canManageTwoFactorAuthentication())
                            <div class="mt-10 sm:mt-0">
                                @livewire('profile.two-factor-authentication-form')
                            </div>
                        @endif

                        <div class="mt-10 sm:mt-0">
                            @livewire('profile.logout-other-browser-sessions-form')
                        </div>
                        @if (Laravel\Jetstream\Jetstream::hasAccountDeletionFeatures())
                            @component('Illuminate\View\AnonymousComponent', 'jet-section-border', ['view' => 'jetstream::components.section-border','data' => []])
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
@endComponentClass

                            <div class="mt-3 sm:mt-0">
                                @livewire('profile.delete-user-form')
                            </div>
                        @endif
                       
                </div>*/
                ?>

                <div id="account_security" class="container tab-pane fade ">
                    <div class="container w-full">
                      <div class="row">
                        <div class="col-sm pt-2">
                                <?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::updatePasswords())): ?>
                                    <div class="mt-10 sm:mt-0">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.update-password-form')->html();
} elseif ($_instance->childHasBeenRendered('mX5FkzI')) {
    $componentId = $_instance->getRenderedChildComponentId('mX5FkzI');
    $componentTag = $_instance->getRenderedChildComponentTagName('mX5FkzI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mX5FkzI');
} else {
    $response = \Livewire\Livewire::mount('profile.update-password-form');
    $html = $response->html();
    $_instance->logRenderedChild('mX5FkzI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                <?php endif; ?>
                        </div>
                        <div class="col-sm pt-2">
                                <?php if(Laravel\Fortify\Features::canManageTwoFactorAuthentication()): ?>
                                    <div class="mt-10 sm:mt-0">
                                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.two-factor-authentication-form')->html();
} elseif ($_instance->childHasBeenRendered('Q2FeJXC')) {
    $componentId = $_instance->getRenderedChildComponentId('Q2FeJXC');
    $componentTag = $_instance->getRenderedChildComponentTagName('Q2FeJXC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Q2FeJXC');
} else {
    $response = \Livewire\Livewire::mount('profile.two-factor-authentication-form');
    $html = $response->html();
    $_instance->logRenderedChild('Q2FeJXC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                    </div>
                                <?php endif; ?>
                        </div>
                        <div class="col-sm pt-2">
                                <div class="mt-10 sm:mt-0">
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('profile.logout-other-browser-sessions-form')->html();
} elseif ($_instance->childHasBeenRendered('xBbhjtz')) {
    $componentId = $_instance->getRenderedChildComponentId('xBbhjtz');
    $componentTag = $_instance->getRenderedChildComponentTagName('xBbhjtz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xBbhjtz');
} else {
    $response = \Livewire\Livewire::mount('profile.logout-other-browser-sessions-form');
    $html = $response->html();
    $_instance->logRenderedChild('xBbhjtz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </div>
                        </div>
                      </div>
                    </div>

                </div>
              </div>
            </div>




        </div>
    

<script type="text/javascript">

$(document).ready(function() {

    // $("#country").select2();
    // $("#province").select2();
    // $("#municipality").select2();

    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })

    
    $("input").on('keyup keydown change paste',function () {
        if ($.trim($(this).val())=="") {
            $(this).addClass('empty');
        } else {
            $(this).removeClass('empty');
        }
    });

    
    $("#hidden_profile_photo").change(function() {
        // var photoName = $refs.photo.files[0].name;
        // const reader = new FileReader();
        // reader.onload = (e) => {
        //     photoPreview = e.target.result;
        // };
        // reader.readAsDataURL($refs.photo.files[0]);
        // alert('Gibs'); return false;
    });

    $("#country").on('change', function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/provinces',
            method: 'get',
            data: {
                'country_code': $(this).val()
            },
            success:function(data){
                $("#province").empty();
                $("#province").append('<option value="">-Select Province-</option>');
                for (var n=0; n<data.length; n++) {
                    $("#province").append("<option>"+data[n]['province']+"</option>");
                }
                $("#municipality").empty();
                $("#municipality").append('<option value="">-Select City/Municipality-</option>');
                $("#barangay").empty();
                $("#barangay").append('<option value="">-Select Barangay-</option>');
                $("#zip_code").val('');
            }
        });
    });

    $("#province").on('change', function() {
        // alert('Country: '+$("#country").val()+'\nProvince: '+$(this).val()); return false;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/cities',
            method: 'get',
            data: {
                'country_code': $("#country").val(),
                'province': $(this).val()
            },
            success:function(data){
                // prompt('',data); return false;
                $("#municipality").empty();
                $("#municipality").append('<option value="">-Select City/Municipality-</option>');
                for (var n=0; n<data.length; n++) {
                    $("#municipality").append("<option>"+data[n]['municipality']+"</option>");
                }
                $("#barangay").empty();
                $("#barangay").append('<option value="">-Select Barangay-</option>');
                $("#zip_code").val('');
                
            }
        });
    });

    $("#municipality").on('change', function() {
        // alert('municipality'); return false;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/barangays',
            method: 'get',
            data: {
                'country_code'  : $("#country").val(),
                'province'      : $("#province").val(),
                'municipality'  : $(this).val()
            },
            success:function(data){
                // prompt('',data); return false;
                $("#barangay").empty();
                $("#barangay").append('<option value="">-Select Barangay-</option>');
                for (var n=0; n<data.length; n++) {
                    $("#barangay").append("<option>"+data[n]['barangay']+"</option>");
                }
                $("#zip_code").val('');
                
            }
        });
    });

    /*$("#barangay").on('change', function() {
        // alert('barangay and zip'); return false;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/zipcodes',
            method: 'get',
            data: {
                'country_code'  : $("#country").val(),
                'province'      : $("#province").val(),
                'municipality'  : $("#municipality").val(),
                'barangay'      : $(this).val(),
            },
            success:function(data){
                $("#zip_code").val(data['zip_code']);
            }
        });
    });*/




    $("#capturePhoto").click(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            url: '/webcam',
            method: 'get',
            success:function(data){
                // prompt('',data);
                // $(".modal-body").html(data);
                $("#modalWebCam").modal("show");
            }
        });
    });
    
    /*$("#capturePhoto").click(function() {
        Webcam.set({
            width: 490,
            height: 350,
            image_format: 'jpeg',
            jpeg_quality: 90
        });
        
        Webcam.attach( '#my_camera' );
        
    });
    function take_snapshot() {
        Webcam.snap( function(data_uri) {
            $(".image-tag").val(data_uri);
            $('#results').removeClass('hidden')
            $('#results').html('<img src="'+data_uri+'"/>');
        } );
    }
    $("#closeWebCamModal").click(function() {
        alert('RNG s');
        Webcam.reset( '#my_camera' );
    });*/

    /* ACCOUNTING DATA - DEPENDENTS */
    var dCounter = $("div.dependents").children("div.dependents").length;
    $(".btnDependents").each(function(){
        $(this).click(function() {
            $(function () {
                // $('#date_applied').datepicker({ dateFormat: 'mm/dd/yy' });
                $('#date_from').datepicker({
                    dateFormat: 'mm/dd/yy',
                    changeMonth: true,
                    changeYear: true,
                    // yearRange: "1900:3000",
                    autoclose: true
                });
                $('#date_to').datepicker({
                    dateFormat: 'mm/dd/yy',
                    changeMonth: true,
                    changeYear: true,
                    autoclose: true
                });

                $('.datepicker').datepicker({
                    dateFormat: 'mm/dd/yy',
                    changeMonth: true,
                    changeYear: true,
                    autoclose: true
                });

                $('#holiday_date').datepicker({
                    dateFormat: 'mm/dd/yy',
                    changeMonth: true,
                    changeYear: true,
                    autoclose: true
                });

            });
            dCounter++;
            console.log(dCounter);
            if (dCounter<=4) {
            $("#dependents")
            .append(`
                    <div class="row dependents">
                        <div class="col-md-8 p-1">
                            <div class="form-floating col-span-8 sm:col-span-1">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'dependent_name${dCounter}','type' => 'text','class' => 'form-control block w-full','wire:model.defer' => 'state.dependent1','autocomplete' => 'off','placeholder' => 'Dependent']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dependent_name${dCounter}','type' => 'text','class' => 'form-control block w-full','wire:model.defer' => 'state.dependent1','autocomplete' => 'off','placeholder' => 'Dependent']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'dependent_name${dCounter}','value' => ''.e(__('Dependent ${dCounter}')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dependent_name${dCounter}','value' => ''.e(__('Dependent ${dCounter}')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'dependent_name1','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dependent_name1','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3 p-1">
                            <div class="form-floating col-span-8 sm:col-span-1">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['id' => 'dependent_birthdate${dCounter}','type' => 'text','class' => 'form-control datepicker block w-full','wire:model.defer' => 'state.dependent_birthdate${dCounter}','placeholder' => 'mm/dd/yyyy']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'dependent_birthdate${dCounter}','type' => 'text','class' => 'form-control datepicker block w-full','wire:model.defer' => 'state.dependent_birthdate${dCounter}','placeholder' => 'mm/dd/yyyy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'dependent_birthdate${dCounter}','value' => ''.e(__('Birthdate')).'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dependent_birthdate${dCounter}','value' => ''.e(__('Birthdate')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input-error','data' => ['for' => 'dependent_birthdate${dCounter}','class' => 'mt-2']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'dependent_birthdate${dCounter}','class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                `);
            }
        });
        return false;
    });

});
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Acer\Desktop\_Gibs\jet_onedoc_project\resources\views/profile/show.blade.php ENDPATH**/ ?>